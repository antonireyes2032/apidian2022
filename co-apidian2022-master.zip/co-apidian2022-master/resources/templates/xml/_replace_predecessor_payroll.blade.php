<ReemplazandoPredecesor
    NumeroPred="{{preg_replace("/[\r\n|\n|\r]+/", "", $predecessor->predecessor_number)}}"
    CUNEPred="{{preg_replace("/[\r\n|\n|\r]+/", "", $predecessor->predecessor_cune)}}"
    FechaGenPred="{{preg_replace("/[\r\n|\n|\r]+/", "", $predecessor->predecessor_issue_date)}}"></ReemplazandoPredecesor>

